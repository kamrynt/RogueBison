Thank you for purchasing Jestan's School Tileset.
The content in this pack is now free for you to use in both free and commercial projects, you may not resell or redistribute it as is.
If you have any questions, please refer to the appropriate community section accesed via the store page.
Remember to leave a review!
I hope you enjoy this pack.